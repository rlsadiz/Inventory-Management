
-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--
-- Creation: Jul 11, 2018 at 11:21 PM
--

CREATE TABLE IF NOT EXISTS `supplier` (
  `id_supplier` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `supplier_code` varchar(4) COLLATE utf16_unicode_ci NOT NULL,
  `supplier_name` varchar(255) COLLATE utf16_unicode_ci NOT NULL,
  `supplier_address` text COLLATE utf16_unicode_ci NOT NULL,
  `supplier_phone` varchar(12) COLLATE utf16_unicode_ci NOT NULL,
  `supplier_email` varchar(60) COLLATE utf16_unicode_ci DEFAULT NULL,
  `contact_person` varchar(40) COLLATE utf16_unicode_ci DEFAULT NULL,
  `supplier_status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_supplier`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `supplier`
--

INSERT IGNORE INTO `supplier` (`id_supplier`, `fk_user`, `supplier_code`, `supplier_name`, `supplier_address`, `supplier_phone`, `supplier_email`, `contact_person`, `supplier_status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Y001', 'Yokohama Tire Sales Philippines, Inc.', 'IE-5 Clark Freeport Zone, Philippines 2023\r\nMabalacat City, Pampanga', '63455993613', NULL, 'Test Person', 1, '2018-06-13 15:04:39', '2018-07-12 23:37:45'),
(2, 1, 'B001', 'Blade Auto Center', '108 Timog Ave, Diliman, Quezon City, 1103 Metro Manila', '63292777777', NULL, NULL, 1, '2018-06-13 19:13:37', '2018-07-12 23:37:51');
