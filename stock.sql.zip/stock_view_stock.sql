
-- --------------------------------------------------------

--
-- Structure for view `stock`
--
DROP TABLE IF EXISTS `stock`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `stock`  AS  select `sku`.`barcode` AS `barcode`,`i`.`sku_code` AS `sku_code`,concat(`p`.`product_name`,' ',`sku`.`variation`) AS `product_name`,sum(`i`.`quantity`) AS `quantity`,max(if((`i`.`type` = 'Purchase'),`i`.`created_at`,NULL)) AS `last_purhase_date`,max(if((`i`.`type` = 'Order'),`i`.`created_at`,NULL)) AS `last_order_date`,`sku`.`critical_quantity` AS `critical_quantity` from ((`inventory` `i` join `product_sku` `sku` on((`sku`.`id_sku` = `i`.`fk_sku`))) join `product` `p` on((`p`.`id_product` = `sku`.`fk_product`))) group by 1 ;
