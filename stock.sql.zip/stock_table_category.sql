
-- --------------------------------------------------------

--
-- Table structure for table `category`
--
-- Creation: Jun 14, 2018 at 03:31 PM
--

CREATE TABLE IF NOT EXISTS `category` (
  `id_category` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `fk_parent_category` int(11) NOT NULL,
  `tree_id` int(11) NOT NULL,
  `category_code` char(3) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `category_name` varchar(255) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `level` tinyint(4) NOT NULL,
  `category_status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_category`),
  UNIQUE KEY `tree_id` (`tree_id`),
  UNIQUE KEY `category_code` (`category_code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT IGNORE INTO `category` (`id_category`, `fk_user`, `fk_parent_category`, `tree_id`, `category_code`, `category_name`, `level`, `category_status`, `created_at`, `updated_at`) VALUES
(1, 1, 0, 0, '---', 'Root', 0, 1, '2018-06-12 18:14:54', '2018-06-13 15:01:38'),
(2, 1, 1, 100000000, 'ACC', 'Accesories', 1, 1, '2018-06-13 06:51:16', '2018-06-14 08:12:22'),
(3, 1, 1, 200000000, 'VHC', 'Vehicle Care', 1, 1, '2018-06-13 06:55:57', '2018-06-13 15:00:15'),
(4, 1, 1, 201000000, 'EVC', 'Exterior Vehicle Care', 2, 1, '2018-06-13 06:53:01', '2018-06-13 15:00:21'),
(5, 1, 1, 300000000, 'CRP', 'Car Parts', 1, 1, '2018-06-13 06:58:40', '2018-06-13 15:00:26'),
(6, 1, 2, 101000000, 'CRC', 'Car Cover', 2, 1, '2018-06-13 07:03:03', '2018-06-13 15:00:31'),
(7, 1, 1, 400000000, 'TIR', 'Tires', 1, 1, '2018-06-13 07:17:11', '2018-06-14 15:07:48'),
(8, 1, 7, 401000000, 'RCT', 'Racing Tires', 2, 1, '2018-06-13 07:17:30', '2018-06-13 15:00:45'),
(9, 1, 7, 402000000, 'ALT', 'All-terrain Tires', 2, 1, '2018-06-13 07:27:35', '2018-06-14 15:08:02'),
(10, 1, 1, 500000000, 'OLF', 'Oil & Fluids', 1, 1, '2018-06-13 15:11:59', '2018-06-14 15:08:20'),
(11, 1, 7, 403000000, 'SPT', 'Sport Tires', 2, 1, '2018-06-14 11:14:35', '2018-06-14 11:14:51');
