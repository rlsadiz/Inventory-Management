
-- --------------------------------------------------------

--
-- Table structure for table `orders`
--
-- Creation: Jul 13, 2018 at 08:35 PM
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id_order` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `fk_discount_reason` int(11) DEFAULT NULL,
  `order_number` bigint(12) NOT NULL,
  `sale_amount` decimal(10,0) NOT NULL,
  `discount_amount` decimal(10,0) NOT NULL,
  `commission_amount` decimal(10,0) NOT NULL,
  `charged_amount` decimal(10,0) NOT NULL,
  `final_amount` decimal(10,0) NOT NULL,
  `vat_sale` decimal(10,0) NOT NULL,
  `non_vat_sale` decimal(10,0) NOT NULL,
  `vat_amount` decimal(10,0) NOT NULL,
  `paid_amount` decimal(10,0) NOT NULL,
  `change_amount` decimal(10,0) NOT NULL,
  `payment_method` varchar(20) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `payment_status` varchar(20) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `order_status` varchar(10) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_order`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
