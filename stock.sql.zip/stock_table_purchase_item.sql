
-- --------------------------------------------------------

--
-- Table structure for table `purchase_item`
--
-- Creation: Jun 13, 2018 at 06:39 PM
--

CREATE TABLE IF NOT EXISTS `purchase_item` (
  `id_purchase_item` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `fk_purchase` int(11) NOT NULL,
  `fk_sku` int(11) NOT NULL,
  `sku_code` char(14) COLLATE utf16_unicode_ci NOT NULL,
  `cost_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `batch_size` int(4) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `units` int(11) NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_purchase_item`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `purchase_item`
--

INSERT IGNORE INTO `purchase_item` (`id_purchase_item`, `fk_user`, `fk_purchase`, `fk_sku`, `sku_code`, `cost_price`, `quantity`, `batch_size`, `total_cost`, `units`, `unit_cost`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 'YKHMA-RCT01-01', '46000.00', 1, 4, '46000.00', 4, '11500.00', '2018-06-13 15:04:24', '2018-06-14 11:34:09'),
(2, 1, 1, 4, 'YKHMA-RCT01-02', '46000.00', 1, 4, '46000.00', 4, '11500.00', '2018-06-13 15:04:24', '2018-06-14 11:34:14');
