
-- --------------------------------------------------------

--
-- Structure for view `price_list`
--
DROP TABLE IF EXISTS `price_list`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `price_list`  AS  select `sku`.`id_sku` AS `id_sku`,`sku`.`sku_code` AS `sku_code`,concat(`p`.`product_name`,' ',`sku`.`variation`) AS `product_name`,`sku`.`cost` AS `cost`,`sku`.`price` AS `price`,min(`pi`.`promotion_price`) AS `promotion_price`,greatest(coalesce(`sku`.`updated_at`,0),coalesce(`pi`.`updated_at`,0)) AS `updated_at` from ((`product_sku` `sku` join `product` `p` on((`p`.`id_product` = `sku`.`fk_product`))) left join `promotion_item` `pi` on(((`sku`.`id_sku` = `pi`.`fk_sku`) and (now() > `pi`.`start_time`) and (now() < `pi`.`end_time`)))) where (`sku`.`sku_status` = 1) group by 1 ;
