
-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--
-- Creation: Jun 13, 2018 at 07:02 PM
--

CREATE TABLE IF NOT EXISTS `purchase` (
  `id_purchase` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `fk_supplier` int(11) NOT NULL,
  `purchase_code` char(9) COLLATE utf16_unicode_ci NOT NULL,
  `cost_amount` decimal(10,2) NOT NULL,
  `paid_amount` decimal(10,2) NOT NULL,
  `purchase_status` varchar(10) COLLATE utf16_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_purchase`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `purchase`
--

INSERT IGNORE INTO `purchase` (`id_purchase`, `fk_user`, `fk_supplier`, `purchase_code`, `cost_amount`, `paid_amount`, `purchase_status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'B001-0001', '92000.00', '92000.00', '3', '2018-06-13 15:04:24', '2018-07-12 23:38:04');
