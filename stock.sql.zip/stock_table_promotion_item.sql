
-- --------------------------------------------------------

--
-- Table structure for table `promotion_item`
--
-- Creation: Jun 14, 2018 at 06:03 AM
--

CREATE TABLE IF NOT EXISTS `promotion_item` (
  `id_promotion_item` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `fk_promotion` int(11) NOT NULL,
  `fk_sku` int(11) NOT NULL,
  `promotion_price` decimal(10,2) NOT NULL,
  `promotion_discount` decimal(10,2) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_promotion_item`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `promotion_item`
--

INSERT IGNORE INTO `promotion_item` (`id_promotion_item`, `fk_user`, `fk_promotion`, `fk_sku`, `promotion_price`, `promotion_discount`, `start_time`, `end_time`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 3, '12000.00', '500.00', '2018-06-14 00:00:00', '2018-06-14 12:00:00', '2018-06-13 17:50:10', '2018-06-14 11:31:54');
