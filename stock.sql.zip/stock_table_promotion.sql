
-- --------------------------------------------------------

--
-- Table structure for table `promotion`
--
-- Creation: Jun 14, 2018 at 06:00 AM
--

CREATE TABLE IF NOT EXISTS `promotion` (
  `id_promotion` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `promotion_name` varchar(255) COLLATE utf16_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_promotion`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `promotion`
--

INSERT IGNORE INTO `promotion` (`id_promotion`, `fk_user`, `promotion_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'Test Promotion', '2018-06-13 17:49:14', '2018-06-14 01:14:05');
