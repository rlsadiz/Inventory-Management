
-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--
-- Creation: Jul 20, 2018 at 12:25 AM
--

CREATE TABLE IF NOT EXISTS `order_item` (
  `id_order_item` int(11) NOT NULL AUTO_INCREMENT,
  `fk_order` int(11) NOT NULL DEFAULT '0',
  `fk_sku` int(11) NOT NULL DEFAULT '0',
  `sku_code` char(16) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `product_name` varchar(255) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `sale_price` decimal(10,0) NOT NULL,
  `discount` decimal(10,0) NOT NULL,
  `final_price` decimal(10,0) NOT NULL,
  `quantity` smallint(6) NOT NULL,
  `sale_amount` decimal(10,0) NOT NULL,
  `discount_amount` decimal(10,0) NOT NULL,
  `final_amount` decimal(10,0) NOT NULL,
  `order_item_status` varchar(10) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_order_item`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
