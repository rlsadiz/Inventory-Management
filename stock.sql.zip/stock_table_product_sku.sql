
-- --------------------------------------------------------

--
-- Table structure for table `product_sku`
--
-- Creation: Jun 14, 2018 at 11:23 AM
--

CREATE TABLE IF NOT EXISTS `product_sku` (
  `id_sku` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `fk_product` int(11) NOT NULL,
  `barcode` char(13) COLLATE utf16_unicode_ci NOT NULL,
  `sku_code` char(14) COLLATE utf16_unicode_ci NOT NULL,
  `variation` varchar(255) COLLATE utf16_unicode_ci NOT NULL,
  `variation_code` varchar(2) COLLATE utf16_unicode_ci NOT NULL,
  `cost` decimal(10,2) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `critical_quantity` tinyint(4) NOT NULL,
  `length` float DEFAULT NULL,
  `width` float DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `sku_status` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_sku`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `product_sku`
--

INSERT IGNORE INTO `product_sku` (`id_sku`, `fk_user`, `fk_product`, `barcode`, `sku_code`, `variation`, `variation_code`, `cost`, `price`, `critical_quantity`, `length`, `width`, `height`, `weight`, `sku_status`, `created_at`, `updated_at`) VALUES
(1, 1, 10, '0021506103286', 'YKHMA-00301', 'P225/45ZR18', '01', '11500.00', '12500.00', 4, NULL, NULL, NULL, NULL, 1, '2018-06-13 16:02:31', '2018-06-14 23:08:41'),
(2, 1, 7, '7262318321311', 'TRTLW-00101', '270g', '01', '400.00', '450.00', 10, NULL, NULL, NULL, NULL, 1, '2018-06-13 16:17:51', '2018-06-14 23:08:50'),
(3, 1, 9, '0071611367004', 'PNNZL-00101', '5W-20 5 quart', '01', '950.00', '1000.00', 4, NULL, NULL, NULL, NULL, 1, '2018-06-13 17:46:12', '2018-06-14 23:08:58'),
(4, 1, 10, '0029142373834', 'YKHMA-00302', 'P245/30ZR19', '02', '11500.00', '13000.00', 4, NULL, NULL, NULL, NULL, 1, '2018-06-13 18:31:53', '2018-06-14 23:09:14'),
(5, 1, 9, '0021400048294', 'PNNZL-00102', '5W-30 1 quart', '02', '290.00', '320.00', 10, NULL, NULL, NULL, NULL, 1, '2018-06-14 11:29:21', '2018-06-14 23:09:37'),
(6, 1, 11, '0071924471078', 'MOBL1-00101', '5w-20 1 quart', '01', '550.00', '660.00', 5, NULL, NULL, NULL, NULL, 1, '2018-06-14 14:49:42', '2018-06-14 23:11:29');
