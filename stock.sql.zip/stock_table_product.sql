
-- --------------------------------------------------------

--
-- Table structure for table `product`
--
-- Creation: Jun 14, 2018 at 11:44 PM
--

CREATE TABLE IF NOT EXISTS `product` (
  `id_product` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `fk_category` int(11) NOT NULL,
  `fk_brand` int(11) NOT NULL,
  `product_code` char(11) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `product_name` varchar(255) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `product_image` text CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `product_status` tinyint(4) NOT NULL,
  `is_vatable` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_product`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT IGNORE INTO `product` (`id_product`, `fk_user`, `fk_category`, `fk_brand`, `product_code`, `product_name`, `product_image`, `product_status`, `is_vatable`, `created_at`, `updated_at`) VALUES
(5, 1, 8, 4, 'YKHMA-001', 'Yokohama Advan A005', '../assests/images/products/YKHMA-001.jpg', 1, 1, '2018-06-13 07:24:12', '2018-06-14 23:04:43'),
(6, 1, 9, 4, 'YKHMA-002', 'Yokohama Geolander A/T G015', '../assests/images/products/YKHMA-002.jpg', 1, 1, '2018-06-13 07:31:43', '2018-06-14 23:04:50'),
(7, 1, 4, 7, 'TRTWX-001', 'Turtle Wax Super Hard Shell Car Wax', '../assests/images/products/TRTWX-001.jpg', 1, 1, '2018-06-13 07:47:39', '2018-06-14 23:04:59'),
(8, 1, 6, 6, 'UNBRN-001', 'Car Cover', '../assests/images/products/UNBRN-001.jpg', 1, 1, '2018-06-13 08:18:30', '2018-06-14 23:05:07'),
(9, 1, 10, 3, 'PNNZL-001', 'Pennzoil Gold Motor Oil', '../assests/images/products/PNNZL-001.jpg', 1, 0, '2018-06-13 17:32:33', '2018-06-14 23:05:23'),
(10, 1, 11, 4, 'YKHMA-003', 'Yokohama Advan Sport', '../assests/images/products/YKHMA-003.jpg', 1, 0, '2018-06-14 11:17:56', '2018-06-14 23:05:33'),
(11, 1, 10, 5, 'MOBL1-001', 'Mobil 1 Annual Protection', '../assests/images/products/MOBL1-001.jpg', 1, 0, '2018-06-14 14:20:24', '2018-06-14 23:05:39');
