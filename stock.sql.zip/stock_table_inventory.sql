
-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--
-- Creation: Jun 13, 2018 at 03:24 PM
--

CREATE TABLE IF NOT EXISTS `inventory` (
  `id_inventory` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `fk_sku` int(11) NOT NULL,
  `type` varchar(20) COLLATE utf16_unicode_ci NOT NULL,
  `sku_code` char(14) COLLATE utf16_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_inventory`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `inventory`
--

INSERT IGNORE INTO `inventory` (`id_inventory`, `fk_user`, `fk_sku`, `type`, `sku_code`, `quantity`, `created_at`) VALUES
(1, 1, 3, 'Initial Stock', 'PNNZL-00101', 2, '2018-06-13 15:48:03'),
(2, 1, 1, 'Purchase', 'YKHMA-00301', 4, '2018-06-13 17:08:40'),
(3, 1, 4, 'Purchase', 'YKHMA-00302', 4, '2018-06-13 17:08:40'),
(4, 1, 2, 'Purchase', 'TRTWX-00101', 15, '2018-06-13 17:19:28'),
(6, 1, 5, 'Purchase', 'PNNZL-00102', 20, '2018-06-14 11:32:56'),
(7, 1, 7, 'Initial Stock', 'YKHMA-00303', 4, '2018-07-10 23:33:57');
