
-- --------------------------------------------------------

--
-- Table structure for table `discount_reason`
--
-- Creation: Jul 08, 2018 at 08:00 AM
--

CREATE TABLE IF NOT EXISTS `discount_reason` (
  `id_discount_reason` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf16_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf16_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_discount_reason`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `discount_reason`
--

INSERT IGNORE INTO `discount_reason` (`id_discount_reason`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Loyal Customer', 'Repeat customers. Eligible for those who bought within the last week.', '2018-07-13 20:34:37', '2018-07-13 20:34:37'),
(2, 'Promotion', 'Promotion for select customers only', '2018-07-13 20:34:37', '2018-07-13 20:34:37');
