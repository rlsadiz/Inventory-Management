
-- --------------------------------------------------------

--
-- Table structure for table `brand`
--
-- Creation: Jun 13, 2018 at 06:49 AM
--

CREATE TABLE IF NOT EXISTS `brand` (
  `id_brand` int(11) NOT NULL AUTO_INCREMENT,
  `fk_user` int(11) NOT NULL,
  `brand_code` char(5) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `brand_name` varchar(255) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `brand_status` tinyint(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_brand`),
  UNIQUE KEY `brand_code` (`brand_code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT IGNORE INTO `brand` (`id_brand`, `fk_user`, `brand_code`, `brand_name`, `brand_status`, `created_at`, `updated_at`) VALUES
(1, 1, 'MCHLN', 'Michelin', 1, '2018-06-13 06:45:06', '2018-07-14 00:57:03'),
(2, 1, 'PRLLI', 'Pirelli', 1, '2018-06-13 06:45:33', '2018-06-13 15:02:16'),
(3, 1, 'PNNZL', 'Pennzoil', 1, '2018-06-13 06:45:45', '2018-06-14 15:11:43'),
(4, 1, 'YKHMA', 'Yokohama', 1, '2018-06-13 06:45:54', '2018-06-13 15:02:43'),
(5, 1, 'MOBL1', 'Mobil 1', 1, '2018-06-13 06:46:03', '2018-06-14 14:18:58'),
(6, 1, 'UNBRN', 'Unbranded', 1, '2018-06-13 06:46:20', '2018-06-13 15:03:12'),
(7, 1, 'TRTWX', 'Turtle Wax', 1, '2018-06-13 07:44:20', '2018-06-14 15:11:01');
